<div class="container">
<div class="row">
    <div class="col-md-12 ">
        <h4> <?php echo $title; ?></h4><hr class="line-title"> 
        <?php 
        if($buku->num_rows() > 0) {
        ?>
        <table class="table table-striped table-bordered table-hover">
            <thead>
                <tr>
                    <td>No.</td>
                    <td>Gambar</td>
                    <td>Kode Buku</td>
                    <td>Judul Buku</td>
                    <td>Pengarang</td>
                    <td>Klasifikasi</td>
                </tr>
            </thead>
            <?php 
                $no=0; 
                foreach($buku->result() as $row): 
                $no++;
            ?>
            <tr>
                <td><?php echo $no;?></td>
                <td><?php if($row->image != "") { ?>
                    <img src="<?php echo base_url('assets/img/buku/'.$row->image);?>" width="100px" height="100px">
                <?php }else{ ?>
                    <img src="<?php echo base_url('assets/img/buku/book-default.jpg');?>" width="100px" height="100px">
                <?php } ?> 
                </td>
                <td><?php echo $row->kode_buku;?></td>
                <td><?php echo $row->judul;?></td>
                <td><?php echo $row->pengarang;?></td>
                <td><?php echo $row->klasifikasi;?></td>
            </tr>
            <?php endforeach;?>
        </table>
        <?php
        echo "$pagination";

        }else{
            echo "Maaf data belum ada";    
        }
        ?>
    </div>
</div>
</div>
